
#include "sdl2game.h"
#include "math.h"
Image* lightstart;
Image* game;
Image* goal;
Image* hook;
Image* goldb1;
Image* goldb2;
Image* golds1;
Image* golds2;
Image* golds3;
Image* golds4;
Image* golds5;
Image* goldm1;
Image* goldm2;
Image* goldm3;
Image* goldm4;



Image* stoneb1;
Image* stoneb2;
Image* stoneb3;
Image* stoneb4;

Image* win;
Image* lose;


double angle=0;
double anglex=1;
double p=3.1415926;
float x=291;
float y=63;
float speedx=3;
float speedy=3;
int money=0;
char* num4;
char* num3;
char* num2;
char* num1;

float second;
int time=180;
char* time3;
char* time2;
char* time1;




int func(int x,int y){
printf("%d\n",x);
printf("%d\n",y);
return 0;
}

/*int funcmax(float x,float y){
int t;
(x>y)?(t=x):(t=y);
return t;
}*/







Bool startword=FALSE;
Bool startclick=FALSE;
Bool startclick2=FALSE;
Bool starting=FALSE;
Bool starting2=FALSE;
Bool fang=FALSE;
Bool shou=FALSE;
Bool gb1yes=FALSE;//���д���1
Bool gb1up=FALSE;//����1��������
Bool gb2yes=FALSE;//���д���2
Bool gb2up=FALSE;//����2��������


Bool gs1yes=FALSE;//����С���1
Bool gs1up=FALSE;//С���2��������
Bool gs2yes=FALSE;//����С���1
Bool gs2up=FALSE;//С���2��������
Bool gs3yes=FALSE;
Bool gs3up=FALSE;
Bool gs4yes=FALSE;
Bool gs4up=FALSE;
Bool gs5yes=FALSE;
Bool gs5up=FALSE;


Bool gm1yes=FALSE;
Bool gm1up=FALSE;
Bool gm2yes=FALSE;
Bool gm2up=FALSE;
Bool gm3yes=FALSE;
Bool gm3up=FALSE;
Bool gm4yes=FALSE;
Bool gm4up=FALSE;


Bool sb1yes=FALSE;
Bool sb1up=FALSE;
Bool sb2yes=FALSE;
Bool sb2up=FALSE;
Bool sb3yes=FALSE;
Bool sb3up=FALSE;
Bool sb4yes=FALSE;
Bool sb4up=FALSE;


Bool timeup=FALSE;







// ��ʼ��
void setup() {
    size(600,450);
    title("�ƽ��");
    bgimage("image/welcome.png");
    lightstart=loadimage("image/welcomego.png");
    game=loadimage("image/game.png");
    goal=loadimage("image/goal.png");
    hook=loadimage("image/hook.png");
    goldb1=loadimage("image/goldbig.png");
    goldb2=loadimage("image/goldbig.png");
    golds1=loadimage("image/goldsmall.png");
    golds2=loadimage("image/goldsmall.png");
    golds3=loadimage("image/goldsmall.png");
    golds4=loadimage("image/goldsmall.png");
    golds5=loadimage("image/goldsmall.png");
    goldm1=loadimage("image/goldmid.png");
    goldm2=loadimage("image/goldmid.png");
    goldm3=loadimage("image/goldmid.png");
    goldm4=loadimage("image/goldmid.png");
    stoneb1=loadimage("image/stonea.png");
    stoneb2=loadimage("image/stoneb.png");
    stoneb3=loadimage("image/stoneb.png");
    stoneb4=loadimage("image/stonea.png");
    win=loadimage("image/win.png");
    lose=loadimage("image/lose.png");
    bgmusic("sound/1.mp3");
}

// �����ͼ
void draw(float stateTime) {
    //��ʾ"Ŀ���"����
    if(startword) image(lightstart,60,110);
    if(startclick){
    starting=TRUE;
    image(goal,0,0);
   }


    //��ʾ��Ϸ����
   if(startclick2){


   image(game,0,0);



   //��ʱ��
   second=second+1.0/60;
   if(second>=1.0){
       second=0;
       time--;
   }
   if(time==0){
       time=0;
       timeup=TRUE;
   }



   if ((time/100)==1) time3="1";
   if ((time/100)==2) time3="2";
   if ((time/100)==3) time3="3";
   if ((time/100)==4) time3="4";
   if ((time/100)==5) time3="5";
   if ((time/100)==6) time3="6";
   if ((time/100)==7) time3="7";
   if ((time/100)==8) time3="8";
   if ((time/100)==9) time3="9";
   if ((time/100)==0) time3="0";


   if (((time/10)%10)==1) time2="1";
   if (((time/10)%10)==2) time2="2";
   if (((time/10)%10)==3) time2="3";
   if (((time/10)%10)==4) time2="4";
   if (((time/10)%10)==5) time2="5";
   if (((time/10)%10)==6) time2="6";
   if (((time/10)%10)==7) time2="7";
   if (((time/10)%10)==8) time2="8";
   if (((time/10)%10)==9) time2="9";
   if (((time/10)%10)==0) time2="0";



   if ((time%10)==1) time1="1";
   if ((time%10)==2) time1="2";
   if ((time%10)==3) time1="3";
   if ((time%10)==4) time1="4";
   if ((time%10)==5) time1="5";
   if ((time%10)==6) time1="6";
   if ((time%10)==7) time1="7";
   if ((time%10)==8) time1="8";
   if ((time%10)==9) time1="9";
   if ((time%10)==0) time1="0";

   text(time3, 565, 30, 215,11,6);
   text(time2, 565+10, 30, 215,11,6);
   text(time1, 565+20, 30, 215,11,6);







   //����ת��
   if ((money/1000)==1) num4="1";
   if ((money/1000)==2) num4="2";
   if ((money/1000)==3) num4="3";
   if ((money/1000)==4) num4="4";
   if ((money/1000)==5) num4="5";
   if ((money/1000)==6) num4="6";
   if ((money/1000)==7) num4="7";
   if ((money/1000)==8) num4="8";
   if ((money/1000)==9) num4="9";
   if ((money/1000)==0) num4="0";


   if (((money/100)%10)==1) num3="1";
   if (((money/100)%10)==2) num3="2";
   if (((money/100)%10)==3) num3="3";
   if (((money/100)%10)==4) num3="4";
   if (((money/100)%10)==5) num3="5";
   if (((money/100)%10)==6) num3="6";
   if (((money/100)%10)==7) num3="7";
   if (((money/100)%10)==8) num3="8";
   if (((money/100)%10)==9) num3="9";
   if (((money/100)%10)==0) num3="0";



   if (((money/10)%10)==1) num2="1";
   if (((money/10)%10)==2) num2="2";
   if (((money/10)%10)==3) num2="3";
   if (((money/10)%10)==4) num2="4";
   if (((money/10)%10)==5) num2="5";
   if (((money/10)%10)==6) num2="6";
   if (((money/10)%10)==7) num2="7";
   if (((money/10)%10)==8) num2="8";
   if (((money/10)%10)==9) num2="9";
   if (((money/10)%10)==0) num2="0";

   if (((money)%10)==1) num1="1";
   if (((money)%10)==2) num1="2";
   if (((money)%10)==3) num1="3";
   if (((money)%10)==4) num1="4";
   if (((money)%10)==5) num1="5";
   if (((money)%10)==6) num1="6";
   if (((money)%10)==7) num1="7";
   if (((money)%10)==8) num1="8";
   if (((money)%10)==9) num1="9";
   if (((money)%10)==0) num1="0";




   //��ʾ����
   /*num4="1";
   num3="1";
   num2="1";
   num1="1";*/
   text("$", 90, 30, 215,11,6);
   text(num4, 100, 30, 215,11,6);
   text(num3, 100+10, 30, 215,11,6);
   text(num2, 100+20, 30, 215,11,6);
   text(num1, 100+30, 30, 215,11,6);





   //��ʾ�����ʯͷ
   if (!gb1yes){
   image(goldb1,40,219);}
   if (!gb2yes){
   image(goldb2,540,262);}


   if (!gs1yes){
   image(golds1,107,128);}
   if (!gs2yes){
   image(golds2,188,195);}
   if (!gs3yes){
   image(golds2,455,196);}
   if (!gs4yes){
   image(golds2,481,158);}
   if (!gs5yes){
   image(golds2,374,258);}


   if (!gm1yes){
   image(goldm1,125,343);}
   if (!gm2yes){
   image(goldm2,21,323);}
   if (!gm3yes){
   image(goldm3,460,340);}

   if (!sb1yes){
   image(stoneb1,191,273);}
   if (!sb2yes){
   image(stoneb2,176,119);}
   if (!sb3yes){
   image(stoneb3,280,345);}
   if (!sb4yes){
   image(stoneb4,391,171);}



     //δ����ǰ�ڹ�
    if(!fang){
    if(angle>75)(anglex=-anglex);
    if(angle<-75)(anglex=-anglex);
    angle=angle+anglex;
    imagerotated(hook,291,63,angle);


    //��ʾ����
    color(0,0,0);
    line(304,55,291+13,63+7);}


     //����֮��Ź�
    if(fang){
    imagerotated(hook,x,y,angle);








        //�����
        if(angle>=0 && angle<=75){


        //���ӵ�λ�ñ仯
        x=x-speedx*sin(angle*3.14159/180);
        y=y+speedy*cos(angle*3.14159/180);


        //��ʾ����
        color(0,0,0);
        line(304,55,x+13,y+7);





        //����goldb1
        if(x>=40-12 && x<=40+60+12 && y>=219-8 && y<=219+70+8 && !gb1up && !shou){
        gb1yes=TRUE;

        }

        if(gb1yes && !gb1up){
            if(y+10>80){image(goldb1,x-60,y+8);
            speedx=-0.6;
            speedy=-0.6;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {gb1up=TRUE;
            shou=FALSE;
            money+=200;
            }
        }

        //����golds1
        if(x>=107-12 && x<=107+19+12 && y>=128-12 && y<=128+18+12 && !gs1up && !shou){
        gs1yes=TRUE;

        }

        if(gs1yes && !gs1up){
            if(y+10>80){image(golds1,x-8,y+8);
            speedx=-3;
            speedy=-3;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {gs1up=TRUE;
            shou=FALSE;
            money+=50;
            }

        }

        //����golds2
        if(x>=188-12 && x<=188+19+12 && y>=195-12 && y<=195+18+12 && !gs2up && !shou){
        gs2yes=TRUE;

        }

        if(gs2yes && !gs2up){
            if(y+10>80){image(golds2,x-8,y+8);
            speedx=-3;
            speedy=-3;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {gs2up=TRUE;
            shou=FALSE;
            money+=50;
            }

        }


        //����goldm1
        if(x>=125-12 && x<=125+33+8 && y>=343-8 && y<=343+30+8 && !gm1up && !shou){
        gm1yes=TRUE;

        }

        if(gm1yes && !gm1up){
            if(y+10>80){image(goldm1,x-8,y+8);
            speedx=-2;
            speedy=-2;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {gm1up=TRUE;
            shou=FALSE;
            money+=100;
            }

        }

        //����goldm2
        if(x>=21-12 && x<=21+33+8 && y>=323-8 && y<=323+30+8 && !gm2up && !shou){
        gm2yes=TRUE;

        }

        if(gm2yes && !gm2up){
            if(y+10>80){image(goldm2,x-8,y+8);
            speedx=-2;
            speedy=-2;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {gm2up=TRUE;
            shou=FALSE;
            money+=100;
            }

        }

        //����stoneb1
        if(x>=191-5 && x<=191+34+5 && y>=273-8 && y<=273+31+8 && !sb1up && !shou){
        sb1yes=TRUE;

        }

        if(sb1yes && !sb1up){
            if(y+10>80){image(stoneb1,x-8,y+8);
            speedx=-0.6;
            speedy=-0.6;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {sb1up=TRUE;
            shou=FALSE;
            money+=10;
            }

        }

       //����stoneb2
        if(x>=176-5 && x<=176+47+5 && y>=119-8 && y<=119+43+8 && !sb2up && !shou){
        sb2yes=TRUE;

        }

        if(sb2yes && !sb2up){
            if(y+10>80){image(stoneb2,x-8,y+8);
            speedx=-0.6;
            speedy=-0.6;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {sb2up=TRUE;
            shou=FALSE;
            money+=10;
            }

        }


        //����stoneb3
        if(x>=280-5 && x<=280+47+5 && y>=345-8 && y<=345+43+8 && !sb3up && !shou){
        sb3yes=TRUE;

        }

        if(sb3yes && !sb3up){
            if(y+10>80){image(stoneb3,x-8,y+8);
            speedx=-0.6;
            speedy=-0.6;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {sb3up=TRUE;
            shou=FALSE;
            money+=10;
            }

        }


        //�չ������
        if(x<=-100 || y>=500){
        speedx=-speedx;
        speedy=-speedy;
        shou=TRUE;
        }



        //���ӷ��ذڶ�λ��
         if(y<63){
        fang=!fang;
        x=291;
        y=63;
        speedx=3;
        speedy=3;
        shou=FALSE;
        }


        }



        //���Ұ�
        if(angle>=-75 && angle<0){


        //���ӵ�λ�ñ仯
        x=x+speedx*sin((-angle)*3.14159/180);
        y=y+speedy*cos(angle*3.14159/180);


        //��ʾ����
        color(0,0,0);
        line(304,55,x+13,y+7);



        //����goldb2
        if(x>=540-12 && x<=540+60+12 && y>=260-8 && y<=260+70+8 && !gb2up && !shou){
        gb2yes=TRUE;

        }

        if(gb2yes && !gb2up){
            if(y+10>80){image(goldb2,x+8,y+8);
            speedx=-0.6;
            speedy=-0.6;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {gb2up=TRUE;
            shou=FALSE;
            money+=200;
            }

        }

        //����golds3
        if(x>=455-12 && x<=455+19+12 && y>=196-8 && y<=196+18+8 && !gs3up && !shou){
        gs3yes=TRUE;

        }

        if(gs3yes && !gs3up){
            if(y+10>80){image(golds3,x+8,y+8);
            speedx=-3;
            speedy=-3;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {gs3up=TRUE;
            shou=FALSE;
            money+=50;
            }

        }



        //����golds4
        if(x>=481-12 && x<=481+19+12 && y>=158-8 && y<=158+18+8 && !gs4up && !shou){
        gs4yes=TRUE;

        }

        if(gs4yes && !gs4up){
            if(y+10>80){image(golds4,x+8,y+8);
            speedx=-3;
            speedy=-3;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {gs4up=TRUE;
            shou=FALSE;
            money+=50;
            }

        }

        //����golds5
        if(x>=374-12 && x<=374+19+12 && y>=258-8 && y<=258+18+8 && !gs5up && !shou){
        gs5yes=TRUE;

        }

        if(gs5yes && !gs5up){
            if(y+10>80){image(golds5,x+8,y+8);
            speedx=-3;
            speedy=-3;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {gs5up=TRUE;
            shou=FALSE;
            money+=50;
            }

        }

        //����goldm3
        if(x>=460-10 && x<=460+33+10 && y>=340-8 && y<=340+30+8 && !gm3up && !shou){
        gm3yes=TRUE;

        }

        if(gm3yes && !gm3up){
            if(y+10>80){image(goldm3,x-8,y+8);
            speedx=-2;
            speedy=-2;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {gm3up=TRUE;
            shou=FALSE;
            money+=100;
            }

        }

       //����stoneb3
        if(x>=280-5 && x<=280+47+5 && y>=345-8 && y<=345+43+8 && !sb3up && !shou){
        sb3yes=TRUE;

        }

        if(sb3yes && !sb3up){
            if(y+10>80){image(stoneb3,x-8,y+8);
            speedx=-0.6;
            speedy=-0.6;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {sb3up=TRUE;
            shou=FALSE;
            money+=10;
            }

        }

        //����stoneb4
        if(x>=391-5 && x<=391+34+5 && y>=171-8 && y<=171+31+8 && !sb4up && !shou){
        sb4yes=TRUE;

        }

        if(sb4yes && !sb4up){
            if(y+10>80){image(stoneb4,x+8,y+8);
            speedx=-0.6;
            speedy=-0.6;
            shou=TRUE;//��ֹ�չ�ʱͬʱ������
            }
            else {sb4up=TRUE;
            shou=FALSE;
            money+=10;
            }

        }

        //�չ������
        if(x>=700 || y>=500){
        speedx=-speedx;
        speedy=-speedy;
        shou=TRUE;
        }



        //���ӷ��ذڶ�λ��
         if(y<63){
        fang=!fang;
        x=291;
        y=63;
        speedx=3;
        speedy=3;
        shou=FALSE;
        }





        }


    }




    if(timeup){
   if (money>=650){
   image(win,0,0);

   }


   if (money<650){
   image(lose,0,0);

   }
   }



    }





}

// ����¼�����
void mousePress() {
    if(inbound(mouseX,mouseY,60,110,120,60) && !starting && !starting2){
    startclick=TRUE;
    }
    //delay(500);
    if(inbound(mouseX,mouseY,0,0,600,450) && starting && !starting2){
    startclick2=TRUE;
    }
    //delay(500);

}
void mouseMove() {
     if(inbound(mouseX,mouseY,60,110,120,60) && !starting && !starting2){
    startword=TRUE;}
    else startword=FALSE;
}
void mouseRelease() {
}

// �����¼���������
void keyDown() {
   if (key==KEY_DOWN) {
    fang=TRUE;}


}
void keyUp() {
}

// �������ʱ������Ϸ��Դ
void close() {
    unloadimage(lightstart);
    unloadimage(game);
    unloadimage(goal);
    unloadimage(hook);
    unloadimage(goldb1);
    unloadimage(goldb2);
    unloadimage(golds1);
    unloadimage(golds2);
    unloadimage(golds3);
    unloadimage(golds4);
    unloadimage(golds5);
    unloadimage(goldm1);
    unloadimage(goldm2);
    unloadimage(goldm3);
    unloadimage(goldm4);
    unloadimage(stoneb1);
    unloadimage(stoneb2);
    unloadimage(stoneb3);
    unloadimage(stoneb4);
    unloadimage(win);
    unloadimage(lose);
}

